blackjack.py = File containing blackjack class
card_deck.py = File containing card deck class
play_blackjack.py = File for running the blackjack game
How to run this program :
1. Download task2.zip
2. Unzip
3. CD to the directory you saved it
4. Type 'py play_blackjack.py' or 'python3 play_blackjack.py'
